#ifndef _LINUX_NTFS_FS_H
#define _LINUX_NTFS_FS_H
#endif
