/* $Id: r39xx.h,v 1.1 2009/11/13 13:22:46 jasonwang Exp $
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file "COPYING" in the main directory of this archive
 * for more details.
 */

#ifndef __R39XX_H__
#define __R39XX_H__

#include <asm/addrspace.h>
 
#endif
