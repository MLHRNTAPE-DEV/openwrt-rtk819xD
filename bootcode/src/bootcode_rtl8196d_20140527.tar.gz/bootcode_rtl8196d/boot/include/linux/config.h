#ifndef _LINUX_CONFIG_H
#define _LINUX_CONFIG_H

#include <linux/autoconf.h>
#include <linux/autoconf2.h>  //wei add,  for make menuconfig more easy use,
#endif
